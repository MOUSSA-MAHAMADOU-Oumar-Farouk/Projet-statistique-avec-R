---
title: "TP 1 - Logiciel statistique R"
author: "MOUSSA MAHAMADOU Oumar Farouk"
date: "2024-04-08"
output:
  html_document:
    toc: true
    toc_depth: 3
    toc_float: true
    number_sections: true
    code_folding: show
    keep_md: true
  pdf_document:
    toc: true
    toc_depth: '3'
---




```r
library(tidyverse) # general wrangling
library(dplyr)
library(readxl)
library(questionr)
library(kableExtra)
library(here)
library(sf)
library(ggplot2)
library(ggspatial)
```

#	Préparation des données

##	Importation et mise en forme 


### Importer la base de données dans un objet de type data.frame nommé projet


```r
# Définition du chemin d'acces

path=here("donnees", "Base_Projet.xlsx")

# importation de la base sous format excel

projet <- read_excel(path)


#View(projet)
```


### Nombre de lignes (i.e. le nombre de PME) et colonnes (i.e. nombre de variables) de la base projet


```r
# Nombre de lignes et de colonnes donnés respectivement par la première et la deuxième sortie
dim(projet)
```

```
## [1] 250  33
```

La base de donnée utilisée dans le cadre de ce travail pratique comporte les informations sur 250 PME et 33 variables qui les caractérisent.


### Vérification de l'existence des valeurs manquantes pour la variable key dans la base projet


```r
is.na(projet$key) # Cette fonction permet de vérifier si oui ou non les valeurs sont de NA
```

Visuellement, il est constaté que la valeur key ne contient pas des NA car toutes les valeurs sont des FALSE.

Mais pour s'assurer d'exactitude de informations constatées, il est possible d'obtenir les indices des valeurs manquantes dans la variable key.


```r
which(is.na(projet$key), arr.ind = T) # fonction pour obtenir les indices des NA dans la variable key
```

```
## integer(0)
```

On obtient la confirmation de cette variable ne contient pas des valeurs manquantes.



##	Création de variables 

### Rénommage de la variable q1 en region


```r
projet = projet |> 
  dplyr::rename(region=q1) # rename permet de renommer la variable q1 en region
```


### Rénommage la variable q2 en departement


```r
projet = projet |> 
  dplyr::rename(departement=q2) # rename permet de renommer la variable q2 en departement
```


###	Rénommer la variable q23 en sexe


```r
projet = projet |> 
  dplyr::rename(sexe=q23) # rename permet de renommer la variable q23 en sexe
```


### Création de la variable 

Cette variable sexe_2 doit valoir 1 si sexe égale à Femme et 0 sinon.


```r
projet = projet |> 
  dplyr::mutate(sexe_2=if_else(sexe=="Femme", 1,0)) 
#la fonction mutate permet de	créer la variable sexe_2 qui vaut 1 si sexe égale à Femme et 0 sinon.
```



### Création d'un nouveau data.frame nommé langues 

Le nouveau data.frame prend les variables key et les variables correspondantes décrites plus haut.


```r
langues = projet |> 
  dplyr::select(c("key", starts_with("q24a_") ))
#création du nouveau data.frame langues en selectionnant la variable key et les variables commençant par q24a_ du data.frame projet
```


### Création d'une variable parle 

La variable `parle` à créer doit etre égale au nombre de langue parlée par le dirigeant de la PME.


```r
#On selectionne les varibles qui commencent par q24a_ qu'on met dans l'objet pl
pl=langues |>
  dplyr::select(starts_with("q24a_")) 

#On crée la nouvelle variable parle en sommant lignes par lignes toutes les variables de l'objet pl
langues <- langues |> 
  mutate(parle = rowSums(pl))
```


### Sélection des variables key et parle

On selectionne les variables key et parle et dont l’objet de retour sera langues.


```r
langues=langues |>
  dplyr::select(c("key", "parle")) 
```


###	Merge des data.frame projet et langues


```r
projet=merge(projet,langues, by="key") #merge des 2 data.frame suivant la clé key
dim(projet) # vérifier si le merge a fonctionné
```

```
## [1] 250  35
```



#	Analyses descriptives 



```r
univarie <- function(data, varia, titre) {
attach(data)
    # Dessiner un graphique en barre
  plot_output <- ggplot2::ggplot(data, aes(varia, fill = varia)) + 
    geom_bar()+
    labs(title = titre, x="", y="") #titre du graphique
  
  print(plot_output)
}
```




### Répartion des PME suivant:

•	Le sexe?


```r
univarie(projet, sexe, "Répartition des PME par sexe")
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-15-1.png)<!-- -->


•	le niveau d’instruction?


```r
univarie(projet, q25, "Répartion des PME suivant le niveau d’instruction")
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-16-1.png)<!-- -->


•	le statut juridique?


```r
univarie(projet, q12, "Répartion des PME suivant le statut juridique")
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-17-1.png)<!-- -->



•	le propriétaire/locataire?


```r
univarie(projet, q81, "Répartion des PME suivant le propriétaire/locataire")
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-18-1.png)<!-- -->

### Analyse bivariée


```r
bivarie  <- function(data, varia1, varia2, titre) {
attach(data)
 tab <- table(varia1, varia2) 
  round(lprop(tab), digits = 1)|>
  kbl(caption = titre) |> 
  kable_classic(full_width = F, html_font = "Cambria", position="left")
}
```

•	le statut juridique et le sexe?


```r
bivarie(projet, q12, sexe, "Statut juridique et le sexe")
```

<table class=" lightable-classic" style="color: black; font-family: Cambria; width: auto !important; ">
<caption>Statut juridique et le sexe</caption>
 <thead>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:right;"> Femme </th>
   <th style="text-align:right;"> Homme </th>
   <th style="text-align:right;"> Total </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Association </td>
   <td style="text-align:right;"> 50.0 </td>
   <td style="text-align:right;"> 50.0 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> GIE </td>
   <td style="text-align:right;"> 83.2 </td>
   <td style="text-align:right;"> 16.8 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Informel </td>
   <td style="text-align:right;"> 84.2 </td>
   <td style="text-align:right;"> 15.8 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> SA </td>
   <td style="text-align:right;"> 14.3 </td>
   <td style="text-align:right;"> 85.7 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> SARL </td>
   <td style="text-align:right;"> 15.4 </td>
   <td style="text-align:right;"> 84.6 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> SUARL </td>
   <td style="text-align:right;"> 57.1 </td>
   <td style="text-align:right;"> 42.9 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Ensemble </td>
   <td style="text-align:right;"> 76.4 </td>
   <td style="text-align:right;"> 23.6 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
</tbody>
</table>

•	le niveau d’instruction et le sexe?



```r
bivarie(projet, q25, sexe, "Le niveau d’instruction et le sexe")
```

<table class=" lightable-classic" style="color: black; font-family: Cambria; width: auto !important; ">
<caption>Le niveau d’instruction et le sexe</caption>
 <thead>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:right;"> Femme </th>
   <th style="text-align:right;"> Homme </th>
   <th style="text-align:right;"> Total </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Aucun niveau </td>
   <td style="text-align:right;"> 88.6 </td>
   <td style="text-align:right;"> 11.4 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Niveau primaire </td>
   <td style="text-align:right;"> 85.7 </td>
   <td style="text-align:right;"> 14.3 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Niveau secondaire </td>
   <td style="text-align:right;"> 75.7 </td>
   <td style="text-align:right;"> 24.3 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Niveau Superieur </td>
   <td style="text-align:right;"> 41.5 </td>
   <td style="text-align:right;"> 58.5 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Ensemble </td>
   <td style="text-align:right;"> 76.4 </td>
   <td style="text-align:right;"> 23.6 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
</tbody>
</table>

•	Propriétaire/locataire suivant le sexe?



```r
bivarie(projet, q81, sexe, "Propriétaire/locataire suivant le sexe")
```

<table class=" lightable-classic" style="color: black; font-family: Cambria; width: auto !important; ">
<caption>Propriétaire/locataire suivant le sexe</caption>
 <thead>
  <tr>
   <th style="text-align:left;">   </th>
   <th style="text-align:right;"> Femme </th>
   <th style="text-align:right;"> Homme </th>
   <th style="text-align:right;"> Total </th>
  </tr>
 </thead>
<tbody>
  <tr>
   <td style="text-align:left;"> Locataire </td>
   <td style="text-align:right;"> 66.7 </td>
   <td style="text-align:right;"> 33.3 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Propriétaire </td>
   <td style="text-align:right;"> 77.4 </td>
   <td style="text-align:right;"> 22.6 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
  <tr>
   <td style="text-align:left;"> Ensemble </td>
   <td style="text-align:right;"> 76.4 </td>
   <td style="text-align:right;"> 23.6 </td>
   <td style="text-align:right;"> 100 </td>
  </tr>
</tbody>
</table>


#	Un peu de cartographie 

## Transformation du data.frame en données géographique


```r
# Conversion le data frame en données géographiques
projet_map <- st_as_sf(projet, coords = c("gps_menlongitude", "gps_menlatitude"), crs = 4326)
```




```r
ggplot() + 
  geom_sf(data=projet_map, aes(color = sexe))
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-24-1.png)<!-- -->




```r
ggplot() +
  # Ajouter les données géographiques avec geom_sf, spécifiant le mapping avec aes()
  geom_sf(data = projet_map, aes(color = sexe)) +
  # Ajouter une flèche pour l'orientation nord
  ggspatial::annotation_north_arrow(location = "bl", which_north = "true", pad_x = unit(0.1, "in"), pad_y = unit(2.9, "in"), size = unit(0.2, "in")) +
  # Personnaliser les aspects de la carte
  labs(title = "Repartition spatiale des PME selon le sexe",
       x = "Longitude", y = "Latitude", # Noms des axes
       color = "Sexe du dirigeant") + # Nom de la légende de couleur
        ggspatial::annotation_scale(location = "br", width_hint = 0.05, text_cex = 0.8) + # Ajouter l'échelle
  theme(axis.title = element_text(size = 12), # Taille du texte des axes
        #legend.position = "bottom", # Position de la légende
        legend.title = element_text(size = 10), # Taille du texte de la légende
        plot.title = element_text(size = 13, face = "bold"), # Taille et style du titre
        #plot.caption = element_text(size = 10), # Taille du texte de la légende
        axis.text = element_text(size = 10)) # Taille du texte des axes
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-25-1.png)<!-- -->



```r
# Spécifier le chemin d'un fichier
path0=here("donnees/gadm41_SEN_shp", "gadm41_SEN_0.shp")
path1=here("donnees/gadm41_SEN_shp", "gadm41_SEN_1.shp")
path2=here("donnees/gadm41_SEN_shp", "gadm41_SEN_2.shp")
path3=here("donnees/gadm41_SEN_shp", "gadm41_SEN_3.shp")
#IMPORTATION DES DONNEES DU SENEGAL
c0_sn <- read_sf(path0)
c1_sn <- read_sf(path1)
c2_sn <- read_sf(path2)
c3_sn <- read_sf(path3)
```



```r
library(ggplot2)

# Créer la carte brute du Sénégal
c0 <- ggplot(c0_sn) +
 aes(fill = COUNTRY) +
 geom_sf() +
 labs(title = "Carte du Sénégal", fill="Pays") +
 annotation_scale(location = "br") +
 annotation_north_arrow(location = "tl", which_north = "true")

c0
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-27-1.png)<!-- -->



```r
c1 <- ggplot() +
  geom_sf(data =c1_sn , aes(fill = NAME_1), color = "black", size = 0.8) +
 labs(title = "Carte Sénégal niveau région", y="latitude",x="longitude",fill="Région")+
  geom_sf_text(data = c1_sn, aes(label = NAME_1), size = 3, color = "black") +  # Ajouter les noms des régions
  annotation_scale(location = "br") +
 annotation_north_arrow(location = "tl", which_north = "true")

c1
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-28-1.png)<!-- -->



```r
### Carte Sénégal niveau département

c2 <- ggplot() +
  geom_sf(data = c2_sn, aes(fill = NAME_2), color = "black", size = 0.8) +
  geom_sf_text(data = c2_sn, aes(label = NAME_2), size = 3, color = "black") +  # Ajouter les noms des régions
  theme(legend.position = "none")+ # Masquer la légende
  annotation_scale(location = "br") +
 annotation_north_arrow(location = "tl", which_north = "true")
c2
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-29-1.png)<!-- -->



```r
c3 <- ggplot() +
  geom_sf(data = c3_sn, aes(fill = NAME_3), color = "black", size = 0.8) +
  labs(title = "Carte Sénégal niveau commune",x="longitude", y="latitude")+
  geom_sf_text(data = c3_sn, aes(label = NAME_3), size = 3, color = "black") +  # Ajouter les noms des régions
  theme(legend.position = "none")+ # Masquer la légende
  annotation_scale(location = "br") +
 annotation_north_arrow(location = "tl", which_north = "true")
c3
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-30-1.png)<!-- -->



```r
## Réprésentation spatiale des PME suivant le sexe

space <- ggplot() +
  geom_sf(data = c1_sn, aes(fill = NAME_1), color = "black", size = 0.8) +
  ggspatial::geom_sf(data = projet_map, ggspatial::aes(color = sexe), size = 2)+
  labs(x="longitude", y="latitude")+
  geom_sf_text(data = c1_sn, aes(label = NAME_1), size = 3, color = "black") +  # Ajouter les noms des régions
  theme(legend.position = "none")+ # Masquer la légende
  annotation_scale(location = "br") +
 annotation_north_arrow(location = "tl", which_north = "true")

space
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-31-1.png)<!-- -->


### Représentation spatiale des PME suivant le niveau d’instruction



```r
## Réprésentation spatiale des PME suivant le niveau d’instruction

space1 <- ggplot() +
  geom_sf(data = c1_sn, aes(fill = NAME_1), color = "black", size = 0.8) +
  ggspatial::geom_sf(data = projet_map, ggspatial::aes(color = q25), size = 2)+
  labs(x="longitude", y="latitude")+
  geom_sf_text(data = c1_sn, aes(label = NAME_1), size = 3, color = "black") +  # Ajouter les noms des régions
  theme(legend.position = "none")+ # Masquer la légende
  annotation_scale(location = "br") +
 annotation_north_arrow(location = "tl", which_north = "true")

space1
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-32-1.png)<!-- -->


### Analyse spatiale au choix


```r
## Réprésentation spatiale des PME suivant le statut

space2 <- ggplot() +
  geom_sf(data = c2_sn, aes(fill = NAME_1), color = "white", size = 0.8) +
  ggspatial::geom_sf(data = projet_map, ggspatial::aes(color = q12), size = 2)+
  labs(x="longitude", y="latitude")+
  geom_sf_text(data = c2_sn, aes(label = NAME_1), size = 3, color = "black") +  # Ajouter les noms des régions
  theme(legend.position = "none")+ # Masquer la légende
  annotation_scale(location = "br") +
 annotation_north_arrow(location = "tl", which_north = "true")

space2
```

![](TP-1---Logiciel-statistique-R_files/figure-html/unnamed-chunk-33-1.png)<!-- -->

